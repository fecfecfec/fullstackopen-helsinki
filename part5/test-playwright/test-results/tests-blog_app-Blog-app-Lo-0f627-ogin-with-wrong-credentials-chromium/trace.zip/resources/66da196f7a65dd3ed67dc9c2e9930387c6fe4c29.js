import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e7e01837"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e7e01837"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=e7e01837"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
import blogService from "/src/services/blogs.js";
const Blog = ({
  blog,
  removeBlogFromList,
  user,
  sumLike
}) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  const addLike = async () => {
    const updatedBlog = {
      id: blog.id,
      title: blog.title,
      author: blog.author,
      url: blog.url,
      likes: blog.likes + 1
    };
    sumLike(updatedBlog);
  };
  const removeBlog = async () => {
    const confirmDelete = window.confirm(`Do you really want to delete ${blog.title}?`);
    if (confirmDelete) {
      try {
        await blogService.remove(blog.id);
        removeBlogFromList(blog.id);
      } catch (error) {
        console.error("Error creating blog:", error);
        console.error("Error creating blog:", error.response.data.error);
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "card", "data-testid": "blog", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "blog-main", children: [
      /* @__PURE__ */ jsxDEV("h4", { className: "flex-grow-1", "data-testid": "blog-title", children: [
        blog.title,
        " by ",
        /* @__PURE__ */ jsxDEV("i", { children: blog.author }, void 0, false, {
          fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
          lineNumber: 54,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
        lineNumber: 53,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "button-container", children: [
        /* @__PURE__ */ jsxDEV("button", { style: hideWhenVisible, onClick: toggleVisibility, children: "View" }, void 0, false, {
          fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
          lineNumber: 57,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { style: showWhenVisible, onClick: toggleVisibility, children: "Hide" }, void 0, false, {
          fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
          lineNumber: 60,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
        lineNumber: 56,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
      lineNumber: 52,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, className: "flex width-100 padding-sm background-color-grey round-corner-sm", "data-testid": "togglable-content", children: [
      /* @__PURE__ */ jsxDEV("a", { href: "{blog.url}", "data-testid": "blog-url", children: blog.url }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
        lineNumber: 66,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-testid": "blog-likes", className: "flex flex-row align-items-center gap-sm", children: [
        "Likes:",
        /* @__PURE__ */ jsxDEV("strong", { "data-testid": "blog-likes-number", children: blog.likes }, void 0, false, {
          fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
          lineNumber: 71,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: addLike, "data-testid": "blog-likes-button", children: "Like" }, void 0, false, {
          fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
          lineNumber: 72,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
        lineNumber: 69,
        columnNumber: 11
      }, this),
      blog.user && /* @__PURE__ */ jsxDEV("div", { children: [
        "Added by ",
        /* @__PURE__ */ jsxDEV("strong", { children: blog.user.name }, void 0, false, {
          fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
          lineNumber: 77,
          columnNumber: 24
        }, this),
        blog.user.username === user.username && /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { onClick: removeBlog, children: "🗑️ Remove blog" }, void 0, false, {
          fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
          lineNumber: 79,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
          lineNumber: 78,
          columnNumber: 56
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
        lineNumber: 76,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
      lineNumber: 65,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
    lineNumber: 51,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx",
    lineNumber: 50,
    columnNumber: 10
  }, this);
};
_s(Blog, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.object.isRequired,
  sumLike: PropTypes.func.isRequired,
  user: PropTypes.object.isRequired,
  removeBlogFromList: PropTypes.func.isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOENJLG1CQUl3QixjQUp4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE5Q0osU0FBU0EsZ0JBQWdCO0FBQ3pCLE9BQU9DLGVBQWU7QUFLdEIsT0FBT0MsaUJBQWlCO0FBRXhCLE1BQU1DLE9BQU9BLENBQUM7QUFBQSxFQUFFQztBQUFBQSxFQUFNQztBQUFBQSxFQUFvQkM7QUFBQUEsRUFBTUM7QUFBUSxNQUFNO0FBQUFDLEtBQUE7QUFDNUQsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlWLFNBQVMsS0FBSztBQUU1QyxRQUFNVyxrQkFBa0I7QUFBQSxJQUFFQyxTQUFTSCxVQUFVLFNBQVM7QUFBQSxFQUFHO0FBQ3pELFFBQU1JLGtCQUFrQjtBQUFBLElBQUVELFNBQVNILFVBQVUsS0FBSztBQUFBLEVBQU87QUFFekQsUUFBTUssbUJBQW1CQSxNQUFNO0FBQzdCSixlQUFXLENBQUNELE9BQU87QUFBQSxFQUNyQjtBQUdBLFFBQU1NLFVBQVUsWUFBWTtBQUMxQixVQUFNQyxjQUFjO0FBQUEsTUFDbEJDLElBQUliLEtBQUthO0FBQUFBLE1BQ1RDLE9BQU9kLEtBQUtjO0FBQUFBLE1BQ1pDLFFBQVFmLEtBQUtlO0FBQUFBLE1BQ2JDLEtBQUtoQixLQUFLZ0I7QUFBQUEsTUFDVkMsT0FBT2pCLEtBQUtpQixRQUFRO0FBQUEsSUFDdEI7QUFDQWQsWUFBUVMsV0FBVztBQUFBLEVBQ3JCO0FBRUEsUUFBTU0sYUFBYSxZQUFZO0FBQzdCLFVBQU1DLGdCQUFnQkMsT0FBT0MsUUFDMUIsZ0NBQStCckIsS0FBS2MsS0FBTSxHQUM3QztBQUNBLFFBQUlLLGVBQWU7QUFDakIsVUFBSTtBQUNGLGNBQU1yQixZQUFZd0IsT0FBT3RCLEtBQUthLEVBQUU7QUFDaENaLDJCQUFtQkQsS0FBS2EsRUFBRTtBQUFBLE1BQzVCLFNBQVNVLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQzNDQyxnQkFBUUQsTUFBTSx3QkFBd0JBLE1BQU1FLFNBQVNDLEtBQUtILEtBQUs7QUFBQSxNQUNqRTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRSxpQ0FBQyxTQUFJLFdBQVUsUUFBTyxlQUFZLFFBQ2hDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsZUFBYyxlQUFZLGNBQ3JDdkI7QUFBQUEsYUFBS2M7QUFBQUEsUUFBTTtBQUFBLFFBQUksdUJBQUMsT0FBR2QsZUFBS2UsVUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdCO0FBQUEsV0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSwrQkFBQyxZQUFPLE9BQU9SLGlCQUFpQixTQUFTRyxrQkFBaUIsb0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxPQUFPRCxpQkFBaUIsU0FBU0Msa0JBQWlCLG9CQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFDQSx1QkFBQyxTQUNDLE9BQU9ELGlCQUNQLFdBQVUsbUVBQ1YsZUFBWSxxQkFFWjtBQUFBLDZCQUFDLE9BQUUsTUFBSyxjQUFhLGVBQVksWUFDOUJULGVBQUtnQixPQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FDQyxlQUFZLGNBQ1osV0FBVSwyQ0FBeUM7QUFBQTtBQUFBLFFBR25ELHVCQUFDLFlBQU8sZUFBWSxxQkFBcUJoQixlQUFLaUIsU0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQ3BELHVCQUFDLFlBQU8sU0FBU04sU0FBUyxlQUFZLHFCQUFtQixvQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNDWCxLQUFLRSxRQUNKLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBQ08sdUJBQUMsWUFBUUYsZUFBS0UsS0FBS3lCLFFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxRQUNoQzNCLEtBQUtFLEtBQUswQixhQUFhMUIsS0FBSzBCLFlBQzNCLHVCQUFDLFNBQ0MsaUNBQUMsWUFBTyxTQUFTVixZQUFZLCtCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDLEtBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQTtBQUFBLE9BMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQ0EsS0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZDQTtBQUVKO0FBQUNkLEdBckZLTCxNQUFJO0FBQUE4QixLQUFKOUI7QUF1Rk5BLEtBQUsrQixZQUFZO0FBQUEsRUFDZjlCLE1BQU1ILFVBQVVrQyxPQUFPQztBQUFBQSxFQUN2QjdCLFNBQVNOLFVBQVVvQyxLQUFLRDtBQUFBQSxFQUN4QjlCLE1BQU1MLFVBQVVrQyxPQUFPQztBQUFBQSxFQUN2Qi9CLG9CQUFvQkosVUFBVW9DLEtBQUtEO0FBQ3JDO0FBRUEsZUFBZWpDO0FBQUksSUFBQThCO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlByb3BUeXBlcyIsImJsb2dTZXJ2aWNlIiwiQmxvZyIsImJsb2ciLCJyZW1vdmVCbG9nRnJvbUxpc3QiLCJ1c2VyIiwic3VtTGlrZSIsIl9zIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJoaWRlV2hlblZpc2libGUiLCJkaXNwbGF5Iiwic2hvd1doZW5WaXNpYmxlIiwidG9nZ2xlVmlzaWJpbGl0eSIsImFkZExpa2UiLCJ1cGRhdGVkQmxvZyIsImlkIiwidGl0bGUiLCJhdXRob3IiLCJ1cmwiLCJsaWtlcyIsInJlbW92ZUJsb2ciLCJjb25maXJtRGVsZXRlIiwid2luZG93IiwiY29uZmlybSIsInJlbW92ZSIsImVycm9yIiwiY29uc29sZSIsInJlc3BvbnNlIiwiZGF0YSIsIm5hbWUiLCJ1c2VybmFtZSIsIl9jIiwicHJvcFR5cGVzIiwib2JqZWN0IiwiaXNSZXF1aXJlZCIsImZ1bmMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJ1xuXG4vLyBDb21wb25lbnRzXG5cbi8vIFNlcnZpY2VzIGFuZCBoZWxwZXJzXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi4vc2VydmljZXMvYmxvZ3MnXG5cbmNvbnN0IEJsb2cgPSAoeyBibG9nLCByZW1vdmVCbG9nRnJvbUxpc3QsIHVzZXIsIHN1bUxpa2UgfSkgPT4ge1xuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBoaWRlV2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnbm9uZScgOiAnJyB9XG4gIGNvbnN0IHNob3dXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICcnIDogJ25vbmUnIH1cblxuICBjb25zdCB0b2dnbGVWaXNpYmlsaXR5ID0gKCkgPT4ge1xuICAgIHNldFZpc2libGUoIXZpc2libGUpXG4gIH1cblxuICAvLyBMaWtlIGJsb2dcbiAgY29uc3QgYWRkTGlrZSA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1cGRhdGVkQmxvZyA9IHtcbiAgICAgIGlkOiBibG9nLmlkLFxuICAgICAgdGl0bGU6IGJsb2cudGl0bGUsXG4gICAgICBhdXRob3I6IGJsb2cuYXV0aG9yLFxuICAgICAgdXJsOiBibG9nLnVybCxcbiAgICAgIGxpa2VzOiBibG9nLmxpa2VzICsgMSxcbiAgICB9XG4gICAgc3VtTGlrZSh1cGRhdGVkQmxvZylcbiAgfVxuXG4gIGNvbnN0IHJlbW92ZUJsb2cgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgY29uZmlybURlbGV0ZSA9IHdpbmRvdy5jb25maXJtKFxuICAgICAgYERvIHlvdSByZWFsbHkgd2FudCB0byBkZWxldGUgJHtibG9nLnRpdGxlfT9gXG4gICAgKVxuICAgIGlmIChjb25maXJtRGVsZXRlKSB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBibG9nU2VydmljZS5yZW1vdmUoYmxvZy5pZClcbiAgICAgICAgcmVtb3ZlQmxvZ0Zyb21MaXN0KGJsb2cuaWQpXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBjcmVhdGluZyBibG9nOicsIGVycm9yKVxuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBjcmVhdGluZyBibG9nOicsIGVycm9yLnJlc3BvbnNlLmRhdGEuZXJyb3IpXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9J2NhcmQnIGRhdGEtdGVzdGlkPSdibG9nJz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Jsb2ctbWFpbic+XG4gICAgICAgICAgPGg0IGNsYXNzTmFtZT0nZmxleC1ncm93LTEnIGRhdGEtdGVzdGlkPSdibG9nLXRpdGxlJz5cbiAgICAgICAgICAgIHtibG9nLnRpdGxlfSBieSA8aT57YmxvZy5hdXRob3J9PC9pPlxuICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2J1dHRvbi1jb250YWluZXInPlxuICAgICAgICAgICAgPGJ1dHRvbiBzdHlsZT17aGlkZVdoZW5WaXNpYmxlfSBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT5cbiAgICAgICAgICAgICAgVmlld1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uIHN0eWxlPXtzaG93V2hlblZpc2libGV9IG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9PlxuICAgICAgICAgICAgICBIaWRlXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBzdHlsZT17c2hvd1doZW5WaXNpYmxlfVxuICAgICAgICAgIGNsYXNzTmFtZT0nZmxleCB3aWR0aC0xMDAgcGFkZGluZy1zbSBiYWNrZ3JvdW5kLWNvbG9yLWdyZXkgcm91bmQtY29ybmVyLXNtJ1xuICAgICAgICAgIGRhdGEtdGVzdGlkPSd0b2dnbGFibGUtY29udGVudCdcbiAgICAgICAgPlxuICAgICAgICAgIDxhIGhyZWY9J3tibG9nLnVybH0nIGRhdGEtdGVzdGlkPSdibG9nLXVybCc+XG4gICAgICAgICAgICB7YmxvZy51cmx9XG4gICAgICAgICAgPC9hPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPSdibG9nLWxpa2VzJ1xuICAgICAgICAgICAgY2xhc3NOYW1lPSdmbGV4IGZsZXgtcm93IGFsaWduLWl0ZW1zLWNlbnRlciBnYXAtc20nXG4gICAgICAgICAgPlxuICAgICAgICAgICAgTGlrZXM6XG4gICAgICAgICAgICA8c3Ryb25nIGRhdGEtdGVzdGlkPSdibG9nLWxpa2VzLW51bWJlcic+e2Jsb2cubGlrZXN9PC9zdHJvbmc+XG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2FkZExpa2V9IGRhdGEtdGVzdGlkPSdibG9nLWxpa2VzLWJ1dHRvbic+XG4gICAgICAgICAgICAgIExpa2VcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtibG9nLnVzZXIgJiYgKFxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgQWRkZWQgYnkgPHN0cm9uZz57YmxvZy51c2VyLm5hbWV9PC9zdHJvbmc+XG4gICAgICAgICAgICAgIHtibG9nLnVzZXIudXNlcm5hbWUgPT09IHVzZXIudXNlcm5hbWUgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3JlbW92ZUJsb2d9PvCfl5HvuI8gUmVtb3ZlIGJsb2c8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gIClcbn1cblxuQmxvZy5wcm9wVHlwZXMgPSB7XG4gIGJsb2c6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZCxcbiAgc3VtTGlrZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgdXNlcjogUHJvcFR5cGVzLm9iamVjdC5pc1JlcXVpcmVkLFxuICByZW1vdmVCbG9nRnJvbUxpc3Q6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2dcbiJdLCJmaWxlIjoiL1VzZXJzL2ZlY2hlL0RldmVsb3AvZnVsbHN0YWNrb3Blbi1ibG9nTGlzdGluZy9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9