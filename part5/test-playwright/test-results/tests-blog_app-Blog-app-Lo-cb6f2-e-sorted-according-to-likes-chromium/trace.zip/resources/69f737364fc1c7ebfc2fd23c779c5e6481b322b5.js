import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e7e01837"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e7e01837"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=e7e01837"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const BlogForm = ({
  createBlog
}) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const handleInputTitle = (event) => {
    setTitle(event.target.value);
  };
  const handleInpuAuthor = (event) => {
    setAuthor(event.target.value);
  };
  const handleInputUrl = (event) => {
    setUrl(event.target.value);
  };
  const addBlog = (event) => {
    event.preventDefault();
    createBlog({
      title,
      author,
      url
    });
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: addBlog, className: "flex padding-sm", children: [
    /* @__PURE__ */ jsxDEV("h3", { children: "Add new blog" }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
      lineNumber: 36,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-sm", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "title", children: "Title:" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
        lineNumber: 38,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "title", "data-testid": "title", value: title, onChange: handleInputTitle }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
        lineNumber: 39,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
      lineNumber: 37,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-sm", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "author", children: "Author:" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
        lineNumber: 42,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "author", "data-testid": "author", value: author, onChange: handleInpuAuthor }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
        lineNumber: 43,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
      lineNumber: 41,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-sm", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "url", children: "URL:" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
        lineNumber: 46,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "url", "data-testid": "url", value: url, onChange: handleInputUrl, placeholder: "http://example.com" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
        lineNumber: 47,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
      lineNumber: 45,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", "data-testid": "submit", children: "Add blog" }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
      lineNumber: 49,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
    lineNumber: 35,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = BlogForm;
BlogForm.propTypes = {
  createBlog: PropTypes.func.isRequired
};
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQS9CUixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxXQUFXQSxDQUFDO0FBQUEsRUFBRUM7QUFBVyxNQUFNO0FBQUFDLEtBQUE7QUFFbkMsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlOLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNPLFFBQVFDLFNBQVMsSUFBSVIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ1MsS0FBS0MsTUFBTSxJQUFJVixTQUFTLEVBQUU7QUFFakMsUUFBTVcsbUJBQW9CQyxXQUFVO0FBQ2xDTixhQUFTTSxNQUFNQyxPQUFPQyxLQUFLO0FBQUEsRUFDN0I7QUFDQSxRQUFNQyxtQkFBb0JILFdBQVU7QUFDbENKLGNBQVVJLE1BQU1DLE9BQU9DLEtBQUs7QUFBQSxFQUM5QjtBQUNBLFFBQU1FLGlCQUFrQkosV0FBVTtBQUNoQ0YsV0FBT0UsTUFBTUMsT0FBT0MsS0FBSztBQUFBLEVBQzNCO0FBR0EsUUFBTUcsVUFBV0wsV0FBVTtBQUN6QkEsVUFBTU0sZUFBZTtBQUNyQmYsZUFBVztBQUFBLE1BQUVFO0FBQUFBLE1BQU9FO0FBQUFBLE1BQVFFO0FBQUFBLElBQUksQ0FBQztBQUNqQ0gsYUFBUyxFQUFFO0FBQ1hFLGNBQVUsRUFBRTtBQUNaRSxXQUFPLEVBQUU7QUFBQSxFQUNYO0FBRUEsU0FDRSx1QkFBQyxTQUNDLGlDQUFDLFVBQUssVUFBVU8sU0FBUyxXQUFVLG1CQUNqQztBQUFBLDJCQUFDLFFBQUcsNEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLElBQ2hCLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkJBQUMsV0FBTSxTQUFRLFNBQVEsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxNQUM3Qix1QkFBQyxXQUNDLElBQUcsU0FDSCxlQUFZLFNBQ1osT0FBT1osT0FDUCxVQUFVTSxvQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSTZCO0FBQUEsU0FOL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDZCQUFDLFdBQU0sU0FBUSxVQUFTLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDL0IsdUJBQUMsV0FDQyxJQUFHLFVBQ0gsZUFBWSxVQUNaLE9BQU9KLFFBQ1AsVUFBVVEsb0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUk2QjtBQUFBLFNBTi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSw2QkFBQyxXQUFNLFNBQVEsT0FBTSxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLFdBQ0MsSUFBRyxPQUNILGVBQVksT0FDWixPQUFPTixLQUNQLFVBQVVPLGdCQUNWLGFBQVksd0JBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtrQztBQUFBLFNBUHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsZUFBWSxVQUFRLHdCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBLEtBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0E7QUFFSjtBQUFDWixHQS9ES0YsVUFBUTtBQUFBaUIsS0FBUmpCO0FBaUVOQSxTQUFTa0IsWUFBWTtBQUFBLEVBQ25CakIsWUFBWUYsVUFBVW9CLEtBQUtDO0FBQzdCO0FBRUEsZUFBZXBCO0FBQVEsSUFBQWlCO0FBQUFJLGFBQUFKLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlByb3BUeXBlcyIsIkJsb2dGb3JtIiwiY3JlYXRlQmxvZyIsIl9zIiwidGl0bGUiLCJzZXRUaXRsZSIsImF1dGhvciIsInNldEF1dGhvciIsInVybCIsInNldFVybCIsImhhbmRsZUlucHV0VGl0bGUiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwiaGFuZGxlSW5wdUF1dGhvciIsImhhbmRsZUlucHV0VXJsIiwiYWRkQmxvZyIsInByZXZlbnREZWZhdWx0IiwiX2MiLCJwcm9wVHlwZXMiLCJmdW5jIiwiaXNSZXF1aXJlZCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2dGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJ1xuXG5jb25zdCBCbG9nRm9ybSA9ICh7IGNyZWF0ZUJsb2cgfSkgPT4ge1xuICAvLyBIYW5kbGUgZm9ybSBzdGF0ZVxuICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbYXV0aG9yLCBzZXRBdXRob3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFt1cmwsIHNldFVybF0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCBoYW5kbGVJbnB1dFRpdGxlID0gKGV2ZW50KSA9PiB7XG4gICAgc2V0VGl0bGUoZXZlbnQudGFyZ2V0LnZhbHVlKVxuICB9XG4gIGNvbnN0IGhhbmRsZUlucHVBdXRob3IgPSAoZXZlbnQpID0+IHtcbiAgICBzZXRBdXRob3IoZXZlbnQudGFyZ2V0LnZhbHVlKVxuICB9XG4gIGNvbnN0IGhhbmRsZUlucHV0VXJsID0gKGV2ZW50KSA9PiB7XG4gICAgc2V0VXJsKGV2ZW50LnRhcmdldC52YWx1ZSlcbiAgfVxuXG4gIC8vIEFkZCBibG9nIHBvc3RcbiAgY29uc3QgYWRkQmxvZyA9IChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBjcmVhdGVCbG9nKHsgdGl0bGUsIGF1dGhvciwgdXJsIH0pXG4gICAgc2V0VGl0bGUoJycpXG4gICAgc2V0QXV0aG9yKCcnKVxuICAgIHNldFVybCgnJylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXthZGRCbG9nfSBjbGFzc05hbWU9J2ZsZXggcGFkZGluZy1zbSc+XG4gICAgICAgIDxoMz5BZGQgbmV3IGJsb2c8L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBnYXAtc20nPlxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPSd0aXRsZSc+VGl0bGU6PC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGlkPSd0aXRsZSdcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPSd0aXRsZSdcbiAgICAgICAgICAgIHZhbHVlPXt0aXRsZX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dFRpdGxlfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBnYXAtc20nPlxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPSdhdXRob3InPkF1dGhvcjo8L2xhYmVsPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgaWQ9J2F1dGhvcidcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPSdhdXRob3InXG4gICAgICAgICAgICB2YWx1ZT17YXV0aG9yfVxuICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHVBdXRob3J9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGdhcC1zbSc+XG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9J3VybCc+VVJMOjwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBpZD0ndXJsJ1xuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3VybCdcbiAgICAgICAgICAgIHZhbHVlPXt1cmx9XG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRVcmx9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj0naHR0cDovL2V4YW1wbGUuY29tJ1xuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uIHR5cGU9J3N1Ym1pdCcgZGF0YS10ZXN0aWQ9J3N1Ym1pdCc+XG4gICAgICAgICAgQWRkIGJsb2dcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuQmxvZ0Zvcm0ucHJvcFR5cGVzID0ge1xuICBjcmVhdGVCbG9nOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nRm9ybVxuIl0sImZpbGUiOiIvVXNlcnMvZmVjaGUvRGV2ZWxvcC9mdWxsc3RhY2tvcGVuLWJsb2dMaXN0aW5nL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2dGb3JtLmpzeCJ9