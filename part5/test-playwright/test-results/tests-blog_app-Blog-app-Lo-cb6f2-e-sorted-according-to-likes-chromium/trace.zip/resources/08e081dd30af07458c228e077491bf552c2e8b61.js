import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e7e01837"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e7e01837"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx?t=1718284548168";
import BlogForm from "/src/components/BlogForm.jsx";
import Message from "/src/components/Message.jsx";
import Togglable from "/src/components/Togglable.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [successMessage, setSuccessMessage] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  useEffect(() => {
    if (user !== null) {
      blogService.getAll().then((blogs2) => setBlogs(blogs2));
    }
  }, [user]);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const blogFormRef = useRef();
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      console.error(exception);
      setErrorMessage(/* @__PURE__ */ jsxDEV(Fragment, { children: [
        "Wrong credentials. ",
        exception.response.data.error
      ] }, void 0, true, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 60,
        columnNumber: 23
      }, this));
      setTimeout(() => {
        setErrorMessage(null);
      }, 3e3);
    }
  };
  const handleLogout = () => {
    setUser(null);
    window.localStorage.removeItem("loggedUser");
    console.log("You have been logged out");
  };
  const removeBlogFromList = (blogId) => {
    setBlogs(blogs.filter((blog) => blog.id !== blogId));
  };
  const addBlog = async (blogObject) => {
    try {
      const returnedBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat(returnedBlog));
      blogFormRef.current.toggleVisibility();
      setSuccessMessage(/* @__PURE__ */ jsxDEV(Fragment, { children: [
        "You've added the article ",
        /* @__PURE__ */ jsxDEV("strong", { children: blogObject.title }, void 0, false, {
          fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
          lineNumber: 84,
          columnNumber: 41
        }, this),
        " to your reading list."
      ] }, void 0, true, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 83,
        columnNumber: 25
      }, this));
      setTimeout(() => {
        setSuccessMessage(null);
      }, 1e4);
    } catch (error) {
      console.error("Error creating blog:", error);
      setErrorMessage(/* @__PURE__ */ jsxDEV(Fragment, { children: [
        "Sorry, there was a problem adding your blog. Reason:",
        " ",
        error.response?.data?.error ?? "An unknown error occurred"
      ] }, void 0, true, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 92,
        columnNumber: 23
      }, this));
      setTimeout(() => {
        setErrorMessage(null);
      }, 4500);
    }
  };
  const addLike = async (blogObject) => {
    try {
      const returnedBlog = await blogService.update(blogObject);
      setBlogs(blogs.map((blog) => blog.id === returnedBlog.id ? returnedBlog : blog));
    } catch (error) {
      console.error("Error creating blog:", error);
      console.error("Error creating blog:", error.response.data.error);
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Login" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 114,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Message, { message: errorMessage, styles: "error" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 115,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "username", children: "Username:" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 116,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "username", "data-testid": "username", value: username, onChange: ({
        target
      }) => setUsername(target.value) }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 117,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "password", children: "Password:" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 122,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "password", "data-testid": "password", type: "password", value: password, onChange: ({
        target
      }) => setPassword(target.value) }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 123,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Log In" }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 127,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
    lineNumber: 112,
    columnNumber: 27
  }, this);
  const blogList = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Blogs" }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 130,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      "👋 ",
      /* @__PURE__ */ jsxDEV("strong", { children: user.name }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 132,
        columnNumber: 12
      }, this),
      " logged in",
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "Log out" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
        lineNumber: 133,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 131,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Message, { message: successMessage }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 135,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Message, { message: errorMessage, styles: "error" }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 136,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", children: /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "Create new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 139,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 138,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 137,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-sm align-items-stretch", children: blogs.sort((a, b) => b.likes - a.likes).map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, user, removeBlogFromList, sumLike: addLike }, blog.id, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 143,
      columnNumber: 62
    }, this)) }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
      lineNumber: 142,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
    lineNumber: 129,
    columnNumber: 26
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: user === null ? loginForm() : blogList() }, void 0, false, {
    fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx",
    lineNumber: 146,
    columnNumber: 10
  }, this);
};
_s(App, "LUHSL4zJeA11hIobNMORSeX99Cw=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/feche/Develop/fullstackopen-blogListing/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE5RHRCLFNBQVNBLFVBQVVDLFdBQVdDLGNBQWM7QUFHNUMsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsZUFBZTtBQUd0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBRXpCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUVoQixRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUlaLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUNhLGNBQWNDLGVBQWUsSUFBSWQsU0FBUyxJQUFJO0FBR3JELFFBQU0sQ0FBQ2UsT0FBT0MsUUFBUSxJQUFJaEIsU0FBUyxFQUFFO0FBR3JDLFFBQU0sQ0FBQ2lCLFVBQVVDLFdBQVcsSUFBSWxCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNtQixVQUFVQyxXQUFXLElBQUlwQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDcUIsTUFBTUMsT0FBTyxJQUFJdEIsU0FBUyxJQUFJO0FBR3JDQyxZQUFVLE1BQU07QUFDZCxRQUFJb0IsU0FBUyxNQUFNO0FBQ2pCZCxrQkFBWWdCLE9BQU8sRUFBRUMsS0FBTVQsWUFBVUMsU0FBU0QsTUFBSyxDQUFDO0FBQUEsSUFDdEQ7QUFBQSxFQUNGLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0FBRVRwQixZQUFVLE1BQU07QUFDZCxVQUFNd0IsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLFlBQVk7QUFDL0QsUUFBSUgsZ0JBQWdCO0FBQ2xCLFlBQU1KLFFBQU9RLEtBQUtDLE1BQU1MLGNBQWM7QUFDdENILGNBQVFELEtBQUk7QUFDWmQsa0JBQVl3QixTQUFTVixNQUFLVyxLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLGNBQWMvQixPQUFPO0FBRzNCLFFBQU1nQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1mLFFBQU8sTUFBTWIsYUFBYTZCLE1BQU07QUFBQSxRQUNwQ3BCO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0YsQ0FBQztBQUdETyxhQUFPQyxhQUFhVyxRQUFRLGNBQWNULEtBQUtVLFVBQVVsQixLQUFJLENBQUM7QUFFOURkLGtCQUFZd0IsU0FBU1YsTUFBS1csS0FBSztBQUMvQlYsY0FBUUQsS0FBSTtBQUNaSCxrQkFBWSxFQUFFO0FBQ2RFLGtCQUFZLEVBQUU7QUFBQSxJQUNoQixTQUFTb0IsV0FBVztBQUNsQkMsY0FBUUMsTUFBTUYsU0FBUztBQUN2QjFCLHNCQUFnQixtQ0FBRTtBQUFBO0FBQUEsUUFBb0IwQixVQUFVRyxTQUFTQyxLQUFLRjtBQUFBQSxXQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9ELENBQUc7QUFDdkVHLGlCQUFXLE1BQU07QUFDZi9CLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFHQSxRQUFNZ0MsZUFBZUEsTUFBTTtBQUN6QnhCLFlBQVEsSUFBSTtBQUNaSSxXQUFPQyxhQUFhb0IsV0FBVyxZQUFZO0FBQzNDTixZQUFRTyxJQUFJLDBCQUEwQjtBQUFBLEVBQ3hDO0FBRUEsUUFBTUMscUJBQXNCQyxZQUFXO0FBQ3JDbEMsYUFBU0QsTUFBTW9DLE9BQVFDLFVBQVNBLEtBQUtDLE9BQU9ILE1BQU0sQ0FBQztBQUFBLEVBQ3JEO0FBR0EsUUFBTUksVUFBVSxPQUFPQyxlQUFlO0FBQ3BDLFFBQUk7QUFDRixZQUFNQyxlQUFlLE1BQU1qRCxZQUFZa0QsT0FBT0YsVUFBVTtBQUN4RHZDLGVBQVNELE1BQU0yQyxPQUFPRixZQUFZLENBQUM7QUFDbkN2QixrQkFBWTBCLFFBQVFDLGlCQUFpQjtBQUNyQ2hELHdCQUNFO0FBQUE7QUFBQSxRQUNnQyx1QkFBQyxZQUFRMkMscUJBQVdNLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUFTO0FBQUEsV0FEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLENBQ0Y7QUFDQWhCLGlCQUFXLE1BQU07QUFDZmpDLDBCQUFrQixJQUFJO0FBQUEsTUFDeEIsR0FBRyxHQUFLO0FBQUEsSUFDVixTQUFTOEIsT0FBTztBQUNkRCxjQUFRQyxNQUFNLHdCQUF3QkEsS0FBSztBQUMzQzVCLHNCQUNFO0FBQUE7QUFBQSxRQUN1RDtBQUFBLFFBQ3BENEIsTUFBTUMsVUFBVUMsTUFBTUYsU0FBUztBQUFBLFdBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxDQUNGO0FBQ0FHLGlCQUFXLE1BQU07QUFDZi9CLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxJQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFHQSxRQUFNZ0QsVUFBVSxPQUFPUCxlQUFlO0FBQ3BDLFFBQUk7QUFDRixZQUFNQyxlQUFlLE1BQU1qRCxZQUFZd0QsT0FBT1IsVUFBVTtBQUN4RHZDLGVBQ0VELE1BQU1pRCxJQUFLWixVQUFVQSxLQUFLQyxPQUFPRyxhQUFhSCxLQUFLRyxlQUFlSixJQUFLLENBQ3pFO0FBQUEsSUFDRixTQUFTVixPQUFPO0FBQ2RELGNBQVFDLE1BQU0sd0JBQXdCQSxLQUFLO0FBQzNDRCxjQUFRQyxNQUFNLHdCQUF3QkEsTUFBTUMsU0FBU0MsS0FBS0YsS0FBSztBQUFBLElBQ2pFO0FBQUEsRUFDRjtBQUVBLFFBQU11QixZQUFZQSxNQUNoQix1QkFBQyxVQUFLLFVBQVUvQixhQUNkO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFTO0FBQUEsTUFDVCx1QkFBQyxXQUFRLFNBQVNyQixjQUFjLFFBQU8sV0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QztBQUFBLE1BQzlDLHVCQUFDLFdBQU0sU0FBUSxZQUFXLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DO0FBQUEsTUFDbkMsdUJBQUMsV0FDQyxJQUFHLFlBQ0gsZUFBWSxZQUNaLE9BQU9JLFVBQ1AsVUFBVSxDQUFDO0FBQUEsUUFBRWlEO0FBQUFBLE1BQU8sTUFBTWhELFlBQVlnRCxPQUFPQyxLQUFLLEtBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJc0Q7QUFBQSxTQVJ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxXQUFNLFNBQVEsWUFBVyx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLE1BQ25DLHVCQUFDLFdBQ0MsSUFBRyxZQUNILGVBQVksWUFDWixNQUFLLFlBQ0wsT0FBT2hELFVBQ1AsVUFBVSxDQUFDO0FBQUEsUUFBRStDO0FBQUFBLE1BQU8sTUFBTTlDLFlBQVk4QyxPQUFPQyxLQUFLLEtBTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLc0Q7QUFBQSxTQVB4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHNCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCO0FBQUEsT0F0QjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFHRixRQUFNQyxXQUFXQSxNQUNmLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsT0FBQztBQUFBO0FBQUEsTUFDRyx1QkFBQyxZQUFRL0MsZUFBS2dELFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQjtBQUFBLE1BQVM7QUFBQSxNQUFXO0FBQUEsTUFDMUMsdUJBQUMsWUFBTyxTQUFTdkIsY0FBYyx1QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQztBQUFBLFNBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsV0FBUSxTQUFTbkMsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUNqQyx1QkFBQyxXQUFRLFNBQVNFLGNBQWMsUUFBTyxXQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFDOUMsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsYUFBVSxhQUFZLG1CQUFrQixLQUFLb0IsYUFDNUMsaUNBQUMsWUFBUyxZQUFZcUIsV0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QixLQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxtQ0FDWnZDLGdCQUNFdUQsS0FBSyxDQUFDQyxHQUFHQyxNQUFNQSxFQUFFQyxRQUFRRixFQUFFRSxLQUFLLEVBQ2hDVCxJQUFLWixVQUNKLHVCQUFDLFFBRUMsTUFDQSxNQUNBLG9CQUNBLFNBQVNVLFdBSkpWLEtBQUtDLElBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUttQixDQUVwQixLQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLE9BekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFHRixTQUFPLHVCQUFDLFNBQUtoQyxtQkFBUyxPQUFPNEMsVUFBVSxJQUFJRyxTQUFTLEtBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0M7QUFDeEQ7QUFBQzFELEdBeEtLRCxLQUFHO0FBQUFpRSxLQUFIakU7QUEwS04sZUFBZUE7QUFBRyxJQUFBaUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQmxvZyIsIkJsb2dGb3JtIiwiTWVzc2FnZSIsIlRvZ2dsYWJsZSIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiQXBwIiwiX3MiLCJzdWNjZXNzTWVzc2FnZSIsInNldFN1Y2Nlc3NNZXNzYWdlIiwiZXJyb3JNZXNzYWdlIiwic2V0RXJyb3JNZXNzYWdlIiwiYmxvZ3MiLCJzZXRCbG9ncyIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwidXNlciIsInNldFVzZXIiLCJnZXRBbGwiLCJ0aGVuIiwibG9nZ2VkVXNlckpTT04iLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImJsb2dGb3JtUmVmIiwiaGFuZGxlTG9naW4iLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwibG9naW4iLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiZXhjZXB0aW9uIiwiY29uc29sZSIsImVycm9yIiwicmVzcG9uc2UiLCJkYXRhIiwic2V0VGltZW91dCIsImhhbmRsZUxvZ291dCIsInJlbW92ZUl0ZW0iLCJsb2ciLCJyZW1vdmVCbG9nRnJvbUxpc3QiLCJibG9nSWQiLCJmaWx0ZXIiLCJibG9nIiwiaWQiLCJhZGRCbG9nIiwiYmxvZ09iamVjdCIsInJldHVybmVkQmxvZyIsImNyZWF0ZSIsImNvbmNhdCIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwidGl0bGUiLCJhZGRMaWtlIiwidXBkYXRlIiwibWFwIiwibG9naW5Gb3JtIiwidGFyZ2V0IiwidmFsdWUiLCJibG9nTGlzdCIsIm5hbWUiLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCdcblxuLy8gQ29tcG9uZW50c1xuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXG5pbXBvcnQgQmxvZ0Zvcm0gZnJvbSAnLi9jb21wb25lbnRzL0Jsb2dGb3JtJ1xuaW1wb3J0IE1lc3NhZ2UgZnJvbSAnLi9jb21wb25lbnRzL01lc3NhZ2UnXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXG5cbi8vIFNlcnZpY2VzIGFuZCBoZWxwZXJzXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcblxuY29uc3QgQXBwID0gKCkgPT4ge1xuICAvLyBNZXNzYWdlc1xuICBjb25zdCBbc3VjY2Vzc01lc3NhZ2UsIHNldFN1Y2Nlc3NNZXNzYWdlXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtlcnJvck1lc3NhZ2UsIHNldEVycm9yTWVzc2FnZV0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIC8vIEJsb2dzXG4gIGNvbnN0IFtibG9ncywgc2V0QmxvZ3NdID0gdXNlU3RhdGUoW10pXG5cbiAgLy8gQXV0aGVudGljYXRpb25cbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcblxuICAvLyBDaGFuZ2VkIHVzZUVmZmVjdCB0byBvbmx5IHJ1biB3aGVuIHVzZXIgaXMgbm90IG51bGwuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHVzZXIgIT09IG51bGwpIHtcbiAgICAgIGJsb2dTZXJ2aWNlLmdldEFsbCgpLnRoZW4oKGJsb2dzKSA9PiBzZXRCbG9ncyhibG9ncykpXG4gICAgfVxuICB9LCBbdXNlcl0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkVXNlcicpXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2dnZWRVc2VySlNPTilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgfVxuICB9LCBbXSlcblxuICBjb25zdCBibG9nRm9ybVJlZiA9IHVzZVJlZigpXG5cbiAgLy8gTG9naW4gSGFuZGxlclxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgbG9naW5TZXJ2aWNlLmxvZ2luKHtcbiAgICAgICAgdXNlcm5hbWUsXG4gICAgICAgIHBhc3N3b3JkLFxuICAgICAgfSlcblxuICAgICAgLy8gU2F2ZSB1c2VyIGluIGxvY2FsIHN0b3JhZ2VcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9nZ2VkVXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXIpKVxuXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgICAgc2V0VXNlcih1c2VyKVxuICAgICAgc2V0VXNlcm5hbWUoJycpXG4gICAgICBzZXRQYXNzd29yZCgnJylcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXhjZXB0aW9uKVxuICAgICAgc2V0RXJyb3JNZXNzYWdlKDw+V3JvbmcgY3JlZGVudGlhbHMuIHtleGNlcHRpb24ucmVzcG9uc2UuZGF0YS5lcnJvcn08Lz4pXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXG4gICAgICB9LCAzMDAwKVxuICAgIH1cbiAgfVxuXG4gIC8vIExvZ291dCBIYW5kbGVyXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcbiAgICBzZXRVc2VyKG51bGwpXG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRVc2VyJylcbiAgICBjb25zb2xlLmxvZygnWW91IGhhdmUgYmVlbiBsb2dnZWQgb3V0JylcbiAgfVxuXG4gIGNvbnN0IHJlbW92ZUJsb2dGcm9tTGlzdCA9IChibG9nSWQpID0+IHtcbiAgICBzZXRCbG9ncyhibG9ncy5maWx0ZXIoKGJsb2cpID0+IGJsb2cuaWQgIT09IGJsb2dJZCkpXG4gIH1cblxuICAvLyBBZGQgYmxvZyBwb3N0IGZyb20gYXV0aGVudGljYXRlZCB1c2VyLlxuICBjb25zdCBhZGRCbG9nID0gYXN5bmMgKGJsb2dPYmplY3QpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmV0dXJuZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UuY3JlYXRlKGJsb2dPYmplY3QpXG4gICAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQocmV0dXJuZWRCbG9nKSlcbiAgICAgIGJsb2dGb3JtUmVmLmN1cnJlbnQudG9nZ2xlVmlzaWJpbGl0eSgpXG4gICAgICBzZXRTdWNjZXNzTWVzc2FnZShcbiAgICAgICAgPD5cbiAgICAgICAgICBZb3UmYXBvczt2ZSBhZGRlZCB0aGUgYXJ0aWNsZSA8c3Ryb25nPntibG9nT2JqZWN0LnRpdGxlfTwvc3Ryb25nPiB0b1xuICAgICAgICAgIHlvdXIgcmVhZGluZyBsaXN0LlxuICAgICAgICA8Lz5cbiAgICAgIClcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRTdWNjZXNzTWVzc2FnZShudWxsKVxuICAgICAgfSwgMTAwMDApXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGNyZWF0aW5nIGJsb2c6JywgZXJyb3IpXG4gICAgICBzZXRFcnJvck1lc3NhZ2UoXG4gICAgICAgIDw+XG4gICAgICAgICAgU29ycnksIHRoZXJlIHdhcyBhIHByb2JsZW0gYWRkaW5nIHlvdXIgYmxvZy4gUmVhc29uOnsnICd9XG4gICAgICAgICAge2Vycm9yLnJlc3BvbnNlPy5kYXRhPy5lcnJvciA/PyAnQW4gdW5rbm93biBlcnJvciBvY2N1cnJlZCd9XG4gICAgICAgIDwvPlxuICAgICAgKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldEVycm9yTWVzc2FnZShudWxsKVxuICAgICAgfSwgNDUwMClcbiAgICB9XG4gIH1cblxuICAvLyBBZGQgYmxvZyBwb3N0IGZyb20gYXV0aGVudGljYXRlZCB1c2VyLlxuICBjb25zdCBhZGRMaWtlID0gYXN5bmMgKGJsb2dPYmplY3QpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmV0dXJuZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UudXBkYXRlKGJsb2dPYmplY3QpXG4gICAgICBzZXRCbG9ncyhcbiAgICAgICAgYmxvZ3MubWFwKChibG9nKSA9PiAoYmxvZy5pZCA9PT0gcmV0dXJuZWRCbG9nLmlkID8gcmV0dXJuZWRCbG9nIDogYmxvZykpXG4gICAgICApXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGNyZWF0aW5nIGJsb2c6JywgZXJyb3IpXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBjcmVhdGluZyBibG9nOicsIGVycm9yLnJlc3BvbnNlLmRhdGEuZXJyb3IpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgbG9naW5Gb3JtID0gKCkgPT4gKFxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0+XG4gICAgICA8ZGl2PlxuICAgICAgICA8aDI+TG9naW48L2gyPlxuICAgICAgICA8TWVzc2FnZSBtZXNzYWdlPXtlcnJvck1lc3NhZ2V9IHN0eWxlcz0nZXJyb3InIC8+XG4gICAgICAgIDxsYWJlbCBodG1sRm9yPSd1c2VybmFtZSc+VXNlcm5hbWU6PC9sYWJlbD5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgaWQ9J3VzZXJuYW1lJ1xuICAgICAgICAgIGRhdGEtdGVzdGlkPSd1c2VybmFtZSdcbiAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVc2VybmFtZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2PlxuICAgICAgICA8bGFiZWwgaHRtbEZvcj0ncGFzc3dvcmQnPlBhc3N3b3JkOjwvbGFiZWw+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGlkPSdwYXNzd29yZCdcbiAgICAgICAgICBkYXRhLXRlc3RpZD0ncGFzc3dvcmQnXG4gICAgICAgICAgdHlwZT0ncGFzc3dvcmQnXG4gICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvbiB0eXBlPSdzdWJtaXQnPkxvZyBJbjwvYnV0dG9uPlxuICAgIDwvZm9ybT5cbiAgKVxuXG4gIGNvbnN0IGJsb2dMaXN0ID0gKCkgPT4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+QmxvZ3M8L2gyPlxuICAgICAgPHA+XG4gICAgICAgIPCfkYsgPHN0cm9uZz57dXNlci5uYW1lfTwvc3Ryb25nPiBsb2dnZWQgaW57JyAnfVxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0+TG9nIG91dDwvYnV0dG9uPlxuICAgICAgPC9wPlxuICAgICAgPE1lc3NhZ2UgbWVzc2FnZT17c3VjY2Vzc01lc3NhZ2V9IC8+XG4gICAgICA8TWVzc2FnZSBtZXNzYWdlPXtlcnJvck1lc3NhZ2V9IHN0eWxlcz0nZXJyb3InIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT0nY2FyZCc+XG4gICAgICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9J0NyZWF0ZSBuZXcgYmxvZycgcmVmPXtibG9nRm9ybVJlZn0+XG4gICAgICAgICAgPEJsb2dGb3JtIGNyZWF0ZUJsb2c9e2FkZEJsb2d9IC8+XG4gICAgICAgIDwvVG9nZ2xhYmxlPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBnYXAtc20gYWxpZ24taXRlbXMtc3RyZXRjaCc+XG4gICAgICAgIHtibG9nc1xuICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcylcbiAgICAgICAgICAubWFwKChibG9nKSA9PiAoXG4gICAgICAgICAgICA8QmxvZ1xuICAgICAgICAgICAgICBrZXk9e2Jsb2cuaWR9XG4gICAgICAgICAgICAgIGJsb2c9e2Jsb2d9XG4gICAgICAgICAgICAgIHVzZXI9e3VzZXJ9XG4gICAgICAgICAgICAgIHJlbW92ZUJsb2dGcm9tTGlzdD17cmVtb3ZlQmxvZ0Zyb21MaXN0fVxuICAgICAgICAgICAgICBzdW1MaWtlPXthZGRMaWtlfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG5cbiAgcmV0dXJuIDxkaXY+e3VzZXIgPT09IG51bGwgPyBsb2dpbkZvcm0oKSA6IGJsb2dMaXN0KCl9PC9kaXY+XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcFxuIl0sImZpbGUiOiIvVXNlcnMvZmVjaGUvRGV2ZWxvcC9mdWxsc3RhY2tvcGVuLWJsb2dMaXN0aW5nL2Zyb250ZW5kL3NyYy9BcHAuanN4In0=