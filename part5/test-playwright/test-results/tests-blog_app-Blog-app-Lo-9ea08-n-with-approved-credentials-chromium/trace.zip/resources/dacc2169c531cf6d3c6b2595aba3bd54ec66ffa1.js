import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Message.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e7e01837"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Message.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Message = ({
  message,
  styles
}) => {
  if (message === null) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: `message ${styles}`, children: message }, void 0, false, {
    fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Message.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
};
_c = Message;
export default Message;
var _c;
$RefreshReg$(_c, "Message");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Message.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS1M7QUFMVCxPQUFNQSxvQkFBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQUVDO0FBQUFBLEVBQVNDO0FBQU8sTUFBTTtBQUN2QyxNQUFJRCxZQUFZLE1BQU07QUFDcEIsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUFPLHVCQUFDLFNBQUksV0FBWSxXQUFVQyxNQUFPLElBQUlELHFCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThDO0FBQ3ZEO0FBQUNFLEtBTktIO0FBUU4sZUFBZUE7QUFBTyxJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTWVzc2FnZSIsIm1lc3NhZ2UiLCJzdHlsZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1lc3NhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IE1lc3NhZ2UgPSAoeyBtZXNzYWdlLCBzdHlsZXMgfSkgPT4ge1xuICBpZiAobWVzc2FnZSA9PT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsXG4gIH1cblxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9e2BtZXNzYWdlICR7c3R5bGVzfWB9PnttZXNzYWdlfTwvZGl2PlxufVxuXG5leHBvcnQgZGVmYXVsdCBNZXNzYWdlXG4iXSwiZmlsZSI6Ii9Vc2Vycy9mZWNoZS9EZXZlbG9wL2Z1bGxzdGFja29wZW4tYmxvZ0xpc3RpbmcvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTWVzc2FnZS5qc3gifQ==