import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e7e01837"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Togglable.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e7e01837"; const useState = __vite__cjsImport3_react["useState"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"]; const forwardRef = __vite__cjsImport3_react["forwardRef"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=e7e01837"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Togglable = _s(forwardRef(_c = _s((props, ref) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  useImperativeHandle(ref, () => {
    return {
      toggleVisibility
    };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Togglable.jsx",
      lineNumber: 23,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Togglable.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, className: "togglableContent", children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "Cancel" }, void 0, false, {
        fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Togglable.jsx",
        lineNumber: 27,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Togglable.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Togglable.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=")), "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c2 = Togglable;
Togglable.displayName = "Togglable";
Togglable.propTypes = {
  buttonLabel: PropTypes.string.isRequired
};
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/feche/Develop/fullstackopen-blogListing/frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCUixTQUFTQSxVQUFVQyxxQkFBcUJDLGtCQUFrQjtBQUMxRCxPQUFPQyxlQUFlO0FBRXRCLE1BQU1DLFlBQVNDLEdBQUdILFdBQVVJLEtBQUFELEdBQUMsQ0FBQ0UsT0FBT0MsUUFBUTtBQUFBSCxLQUFBO0FBQzNDLFFBQU0sQ0FBQ0ksU0FBU0MsVUFBVSxJQUFJVixTQUFTLEtBQUs7QUFFNUMsUUFBTVcsa0JBQWtCO0FBQUEsSUFBRUMsU0FBU0gsVUFBVSxTQUFTO0FBQUEsRUFBRztBQUN6RCxRQUFNSSxrQkFBa0I7QUFBQSxJQUFFRCxTQUFTSCxVQUFVLEtBQUs7QUFBQSxFQUFPO0FBRXpELFFBQU1LLG1CQUFtQkEsTUFBTTtBQUM3QkosZUFBVyxDQUFDRCxPQUFPO0FBQUEsRUFDckI7QUFFQVIsc0JBQW9CTyxLQUFLLE1BQU07QUFDN0IsV0FBTztBQUFBLE1BQ0xNO0FBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFFRCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLE9BQU9ILGlCQUNWLGlDQUFDLFlBQU8sU0FBU0csa0JBQW1CUCxnQkFBTVEsZUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRCxLQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBT0YsaUJBQWlCLFdBQVUsb0JBQ3BDTjtBQUFBQSxZQUFNUztBQUFBQSxNQUNQLHVCQUFDLFlBQU8sU0FBU0Ysa0JBQWtCLHNCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsU0FGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFSixHQUFDLGtDQUFDO0FBQUFHLE1BM0JJYjtBQTZCTkEsVUFBVWMsY0FBYztBQUV4QmQsVUFBVWUsWUFBWTtBQUFBLEVBQ3BCSixhQUFhWixVQUFVaUIsT0FBT0M7QUFDaEM7QUFFQSxlQUFlakI7QUFBUyxJQUFBRSxJQUFBVztBQUFBSyxhQUFBaEIsSUFBQTtBQUFBZ0IsYUFBQUwsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlSW1wZXJhdGl2ZUhhbmRsZSIsImZvcndhcmRSZWYiLCJQcm9wVHlwZXMiLCJUb2dnbGFibGUiLCJfcyIsIl9jIiwicHJvcHMiLCJyZWYiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJ0b2dnbGVWaXNpYmlsaXR5IiwiYnV0dG9uTGFiZWwiLCJjaGlsZHJlbiIsIl9jMiIsImRpc3BsYXlOYW1lIiwicHJvcFR5cGVzIiwic3RyaW5nIiwiaXNSZXF1aXJlZCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRvZ2dsYWJsZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUltcGVyYXRpdmVIYW5kbGUsIGZvcndhcmRSZWYgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcblxuY29uc3QgVG9nZ2xhYmxlID0gZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBoaWRlV2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnbm9uZScgOiAnJyB9XG4gIGNvbnN0IHNob3dXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICcnIDogJ25vbmUnIH1cblxuICBjb25zdCB0b2dnbGVWaXNpYmlsaXR5ID0gKCkgPT4ge1xuICAgIHNldFZpc2libGUoIXZpc2libGUpXG4gIH1cblxuICB1c2VJbXBlcmF0aXZlSGFuZGxlKHJlZiwgKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICB0b2dnbGVWaXNpYmlsaXR5LFxuICAgIH1cbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9Pntwcm9wcy5idXR0b25MYWJlbH08L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBzdHlsZT17c2hvd1doZW5WaXNpYmxlfSBjbGFzc05hbWU9J3RvZ2dsYWJsZUNvbnRlbnQnPlxuICAgICAgICB7cHJvcHMuY2hpbGRyZW59XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+Q2FuY2VsPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufSlcblxuVG9nZ2xhYmxlLmRpc3BsYXlOYW1lID0gJ1RvZ2dsYWJsZSdcblxuVG9nZ2xhYmxlLnByb3BUeXBlcyA9IHtcbiAgYnV0dG9uTGFiZWw6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbn1cblxuZXhwb3J0IGRlZmF1bHQgVG9nZ2xhYmxlXG4iXSwiZmlsZSI6Ii9Vc2Vycy9mZWNoZS9EZXZlbG9wL2Z1bGxzdGFja29wZW4tYmxvZ0xpc3RpbmcvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvVG9nZ2xhYmxlLmpzeCJ9